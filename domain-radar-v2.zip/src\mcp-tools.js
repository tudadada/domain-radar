import {
  ListToolsRequestSchema,
  CallToolRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";
import { INDUSTRY_DICTIONARIES, INFIX_MODIFIERS, DIGIT_PATTERNS } from "./constants.js";
import { checkDomainStatus } from "./rdap.js";
import { probeDomainActivity } from "./probe.js";
import { asyncPool } from "./utils.js";

export function registerTools(server) {
  server.setRequestHandler(ListToolsRequestSchema, async () => {
    return {
      tools: [
        {
          name: "get_domain_whois",
          title: "Get Domain WHOIS & Registration Details",
          description: "Retrieve RDAP/WHOIS details for a specific domain including creation date, expiry date, registrant status, and current live activity status.",
          inputSchema: {
            type: "object",
            properties: {
              domain: { type: "string", description: "The full domain name to query (e.g. example.com)" }
            },
            required: ["domain"],
          },
        },
        {
          name: "search_keyword_domains",
          title: "DotDB-Style Keyword Domain Intelligence",
          description: "Full DotDB-style domain search engine. Supports keyword placement, character toggles, site status filtering, and custom extensions.",
          inputSchema: {
            type: "object",
            properties: {
              keyword: { type: "string" },
              position: { type: "string", enum: ["beginning", "end", "any"], default: "any" },
              include_alphabets: { type: "boolean", default: true },
              include_digits: { type: "boolean", default: true },
              include_hyphens: { type: "boolean", default: true },
              site_status_filter: { type: "array", items: { type: "string", enum: ["active", "parked", "inactive", "unregistered", "all"] }, default: ["all"] },
              extensions: { type: "array", items: { type: "string" }, default: ["com"] },
              industry: { type: "string", enum: ["general", "tech", "energy", "finance", "arctic", "security", "custom"], default: "general" },
              custom_words: { type: "array", items: { type: "string" }, description: "Custom prefix/suffix words if industry is 'custom'" },
              min_length: { type: "integer" },
              max_length: { type: "integer" },
              exclude: { type: "string" },
            },
            required: ["keyword"],
          },
        },
        {
          name: "scan_keyword_tlds",
          title: "Scan Keyword TLD Coverage Matrix",
          description: "Audits a core keyword across major authoritative RDAP registries to report commercial registration density.",
          inputSchema: {
            type: "object",
            properties: {
              keyword: { type: "string" },
              tlds: { type: "array", items: { type: "string" } },
            },
            required: ["keyword"],
          },
        },
        {
          name: "search_keyword_combinations",
          description: "Alias for search_keyword_domains.",
          inputSchema: {
            type: "object",
            properties: {
              keyword: { type: "string" },
              position: { type: "string", enum: ["beginning", "end", "any", "prefix", "suffix", "inside", "all"] },
              include_alphabets: { type: "boolean" },
              include_digits: { type: "boolean" },
              include_hyphens: { type: "boolean" },
              extensions: { type: "array", items: { type: "string" } },
            },
            required: ["keyword"],
          },
        },
        {
          name: "find_available_combinations",
          description: "Legacy Combinations Alias",
          inputSchema: {
            type: "object",
            properties: {
              keyword: { type: "string" },
              position: { type: "string" },
              industry: { type: "string" },
            },
            required: ["keyword"],
          },
        },
      ],
    };
  });

  server.setRequestHandler(CallToolRequestSchema, async (request) => {
    const { name, arguments: args } = request.params;

    if (name === "get_domain_whois") {
      const domain = (args?.domain || "").toLowerCase().trim();
      if (!domain || !domain.includes(".")) throw new Error("A valid domain is required");
      
      const parts = domain.split(".");
      const tld = parts.slice(1).join(".");
      
      const rdapResult = await checkDomainStatus(domain, tld, true);
      const activityResult = await probeDomainActivity(domain);
      
      // Clean up heavy raw payload for cleaner output
      if (rdapResult?.details?.raw) delete rdapResult.details.raw;

      return {
        content: [
          {
            type: "text",
            text: JSON.stringify(
              {
                domain,
                registry_status: rdapResult,
                live_activity: activityResult,
                audited_at: new Date().toISOString()
              },
              null,
              2
            ),
          },
        ],
      };
    }

    const rawKw = (args?.keyword || "").toLowerCase().replace(/[^a-z0-9-]/g, "");
    if (!rawKw) throw new Error("A valid keyword is required");

    if (name === "scan_keyword_tlds") {
      const rawTlds = Array.isArray(args?.tlds) && args.tlds.length > 0
        ? args.tlds.map((t) => t.replace(/^\./, "").toLowerCase())
        : ["com", "net", "org", "ai", "io", "xyz", "tech", "app", "cloud", "co", "de"];

      const registryResults = {};
      await asyncPool(5, rawTlds, async (t) => {
        const domain = `${rawKw}.${t}`;
        registryResults[domain] = await checkDomainStatus(domain, t);
      });

      const takenDomains = Object.keys(registryResults).filter(d => registryResults[d] === "TAKEN");
      const unregisteredDomains = Object.keys(registryResults).filter(d => registryResults[d] === "NOT_FOUND_IN_REGISTRY");

      const activityReport = {};
      if (takenDomains.length > 0) {
        await asyncPool(5, takenDomains, async (dom) => {
          activityReport[dom] = await probeDomainActivity(dom);
        });
      }

      const activeInUse = takenDomains.filter(d => activityReport[d]?.status === "ACTIVE");
      const parkedDomains = takenDomains.filter(d => activityReport[d]?.status === "PARKED");
      const inactiveDomains = takenDomains.filter(d => activityReport[d]?.status === "INACTIVE");

      return {
        content: [
          {
            type: "text",
            text: JSON.stringify(
              {
                keyword: rawKw,
                total_extensions_audited: rawTlds.length,
                summary: {
                  unregistered_available: unregisteredDomains.length,
                  registered_total: takenDomains.length,
                  active_websites_in_use: activeInUse.length,
                  parked_for_sale: parkedDomains.length,
                  inactive_dormant: inactiveDomains.length,
                },
                unregistered_extensions: unregisteredDomains,
                active_domains_in_use: activeInUse,
                parked_for_sale_domains: parkedDomains,
                inactive_dormant_domains: inactiveDomains,
                detailed_activity: activityReport,
                audited_at: new Date().toISOString(),
                verified_by: "Authoritative IANA RDAP Registry & Live Network Probe",
              },
              null,
              2
            ),
          },
        ],
      };
    }

    if (
      name === "search_keyword_domains" ||
      name === "search_keyword_combinations" ||
      name === "find_available_combinations"
    ) {
      let pos = args?.position || "any";
      if (pos === "prefix") pos = "beginning";
      if (pos === "suffix") pos = "end";
      if (pos === "inside" || pos === "all" || pos === "both") pos = "any";

      const incAlpha = args?.include_alphabets !== false;
      const incDigits = args?.include_digits !== false;
      const incHyphens = args?.include_hyphens !== false;
      const ind = args?.industry || "general";
      const excludeStr = (args?.exclude || "").toLowerCase();
      const minLen = typeof args?.min_length === "number" ? args.min_length : 0;
      const maxLen = typeof args?.max_length === "number" ? args.max_length : 63;

      const statusFilter = Array.isArray(args?.site_status_filter) && args.site_status_filter.length > 0
        ? args.site_status_filter.map(s => s.toLowerCase())
        : ["all"];

      const rawTlds = Array.isArray(args?.extensions) && args.extensions.length > 0
        ? args.extensions.map(t => t.replace(/^\./, "").toLowerCase())
        : Array.isArray(args?.tlds) && args.tlds.length > 0
        ? args.tlds.map(t => t.replace(/^\./, "").toLowerCase())
        : ["com"];

      let dict = INDUSTRY_DICTIONARIES[ind] || INDUSTRY_DICTIONARIES.general;
      if (ind === "custom" && Array.isArray(args?.custom_words)) {
        dict = args.custom_words.map(w => w.toLowerCase().replace(/[^a-z0-9-]/g, "")).filter(Boolean);
      }

      const stems = new Set();
      const addStem = (left, right) => {
        stems.add(`${left}${right}`);
        if (incHyphens) stems.add(`${left}-${right}`);
      };
      const addTripleStem = (mod, core, word) => {
        stems.add(`${mod}${core}${word}`);
        if (incHyphens) stems.add(`${mod}-${core}-${word}`);
      };

      if (incAlpha) {
        if (pos === "beginning" || pos === "any") {
          for (const w of dict) addStem(rawKw, w);
        }
        if (pos === "end" || pos === "any") {
          for (const w of dict) addStem(w, rawKw);
        }
        if (pos === "any") {
          for (const mod of INFIX_MODIFIERS.slice(0, 4)) {
            for (const w of dict.slice(0, 3)) addTripleStem(mod, rawKw, w);
          }
        }
      }

      if (incDigits) {
        if (pos === "beginning" || pos === "any") {
          for (const d of DIGIT_PATTERNS) addStem(rawKw, d);
        }
        if (pos === "end" || pos === "any") {
          for (const d of DIGIT_PATTERNS) addStem(d, rawKw);
        }
      }

      const filteredStems = Array.from(stems).filter((s) => {
        if (minLen > 0 && s.length < minLen) return false;
        if (maxLen < 63 && s.length > maxLen) return false;
        if (excludeStr && s.includes(excludeStr)) return false;
        return true;
      });

      const uniqueCandidates = [];
      const uniqueMap = new Set();
      for (const s of filteredStems) {
        for (const t of rawTlds) {
          const domain = `${s}.${t}`;
          if (!uniqueMap.has(domain)) {
            uniqueMap.add(domain);
            uniqueCandidates.push({ domain, tld: t });
          }
        }
      }

      const rdapStatus = {};
      await asyncPool(5, uniqueCandidates, async (c) => {
        rdapStatus[c.domain] = await checkDomainStatus(c.domain, c.tld);
      });

      const unregisteredList = uniqueCandidates.filter(c => rdapStatus[c.domain] === "NOT_FOUND_IN_REGISTRY").map(c => c.domain);
      const takenCandidates = uniqueCandidates.filter(c => rdapStatus[c.domain] === "TAKEN");

      const activityReport = {};
      if (takenCandidates.length > 0) {
        await asyncPool(5, takenCandidates, async (c) => {
          activityReport[c.domain] = await probeDomainActivity(c.domain);
        });
      }

      const activeList = takenCandidates.filter(c => activityReport[c.domain]?.status === "ACTIVE").map(c => c.domain);
      const parkedList = takenCandidates.filter(c => activityReport[c.domain]?.status === "PARKED").map(c => c.domain);
      const inactiveList = takenCandidates.filter(c => activityReport[c.domain]?.status === "INACTIVE").map(c => c.domain);

      const filterAll = statusFilter.includes("all");
      const wantActive = filterAll || statusFilter.includes("active");
      const wantParked = filterAll || statusFilter.includes("parked");
      const wantInactive = filterAll || statusFilter.includes("inactive");
      const wantUnregistered = filterAll || statusFilter.includes("unregistered");

      return {
        content: [
          {
            type: "text",
            text: JSON.stringify(
              {
                search_query: {
                  keyword: rawKw,
                  position: pos,
                  includes: { alphabets: incAlpha, digits: incDigits, hyphens: incHyphens },
                  extensions_scanned: rawTlds,
                  site_status_filter: statusFilter,
                },
                summary_statistics: {
                  total_evaluated: uniqueCandidates.length,
                  unregistered_available_count: unregisteredList.length,
                  registered_total_count: takenCandidates.length,
                  site_status_breakdown: {
                    active_in_use_count: activeList.length,
                    parked_for_sale_count: parkedList.length,
                    inactive_dormant_count: inactiveList.length,
                  },
                },
                results: {
                  unregistered_domains: wantUnregistered ? unregisteredList : undefined,
                  active_domains_in_use: wantActive ? activeList : undefined,
                  parked_for_sale_domains: wantParked ? parkedList : undefined,
                  inactive_dormant_domains: wantInactive ? inactiveList : undefined,
                },
                site_status_details: activityReport,
                verified_by: "DotDB-Standard Engine (Authoritative RDAP + Live HTTP Probe)",
              },
              null,
              2
            ),
          },
        ],
      };
    }

    throw new Error(`Tool ${name} not found`);
  });
}
