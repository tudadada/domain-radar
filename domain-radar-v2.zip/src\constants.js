export const USER_AGENT = "domain-radar/2.0.0 (https://insight.surf; support@insight.surf)";
export const BROWSER_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";

export const INDUSTRY_DICTIONARIES = {
  general: ["pro", "hub", "point", "base", "network", "direct", "online", "group", "world", "zone", "link", "shop", "club", "center"],
  tech: ["ai", "data", "cloud", "core", "labs", "systems", "tech", "protocol", "intel", "node", "cyber", "stack"],
  energy: ["power", "energy", "oil", "gas", "marine", "subsea", "grid", "clean", "solar", "battery", "green"],
  finance: ["capital", "fund", "ventures", "invest", "holdings", "group", "wealth", "trust", "equity", "asset"],
  arctic: ["geo", "drilling", "permafrost", "risk", "ice", "polar", "climate", "carbon", "frost", "cold"],
  security: ["sec", "defense", "audit", "guard", "safe", "shield", "auth", "trust", "lock", "cyber"],
};

export const INFIX_MODIFIERS = ["the", "my", "get", "top", "pro", "global", "smart", "all", "best"];

export const DIGIT_PATTERNS = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "24", "360", "365", "247", "101", "88", "99", "2026"];

export const BUILTIN_RDAP_BASES = {
  com: "https://rdap.verisign.com/com/v1/domain/",
  net: "https://rdap.verisign.com/net/v1/domain/",
  org: "https://rdap.publicinterestregistry.org/rdap/domain/",
  info: "https://rdap.identitydigital.services/rdap/domain/",
  biz: "https://rdap.nic.biz/domain/",
  ca: "https://rdap.ca.fury.ca/rdap/domain/",
  de: "https://rdap.denic.de/domain/",
  io: "https://rdap.identitydigital.services/rdap/domain/",
  ai: "https://rdap.identitydigital.services/rdap/domain/",
  xyz: "https://rdap.centralnic.com/xyz/domain/",
  tech: "https://rdap.radix.host/rdap/domain/",
  app: "https://pubapi.registry.google/rdap/domain/",
  cloud: "https://rdap.registry.cloud/rdap/domain/",
  co: "https://rdap.nic.co/domain/",
};

export const PARKED_KEYWORDS = [
  "domain for sale",
  "buy this domain",
  "sedoparking",
  "dan.com",
  "hugedomains",
  "parked free",
  "this domain is parked",
  "inquire about this domain",
  "domain is for sale",
  "is parked",
  "afternic",
  "squadhelp",
  "namecheap parking",
  "godaddy parking",
  "domain owner",
  "this page is parked"
];
