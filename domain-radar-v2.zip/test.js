import { checkDomainStatus } from "./src/rdap.js";
import { probeDomainActivity } from "./src/probe.js";

async function test() {
  console.log("Testing RDAP google.com...");
  const rdap = await checkDomainStatus("google.com", "com", true);
  console.log(JSON.stringify(rdap, null, 2));
  
  console.log("Testing probe google.com...");
  const probe = await probeDomainActivity("google.com");
  console.log(JSON.stringify(probe, null, 2));

  console.log("Testing RDAP notfound-something-random-123456.com...");
  const rdapNotFound = await checkDomainStatus("notfound-something-random-123456.com", "com", true);
  console.log(JSON.stringify(rdapNotFound, null, 2));
}
test();
