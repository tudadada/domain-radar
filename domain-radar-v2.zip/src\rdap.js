import { USER_AGENT, BUILTIN_RDAP_BASES } from "./constants.js";
import { fetchWithTimeout } from "./utils.js";
import net from "net";
import dns from "dns/promises";

let ianaBootstrapCache = null;
let ianaBootstrapPromise = null;

export async function getIanaMap() {
  if (ianaBootstrapCache) return ianaBootstrapCache;
  if (!ianaBootstrapPromise) {
    ianaBootstrapPromise = (async () => {
      try {
        const res = await fetchWithTimeout("https://data.iana.org/rdap/dns.json", {
          headers: { "User-Agent": USER_AGENT },
          timeout: 4000
        });
        if (!res.ok) throw new Error("Failed to fetch IANA map");
        const json = await res.json();
        const map = {};
        for (const [tlds, urls] of json.services) {
          for (const t of tlds) {
            const u = urls[0].endsWith("/") ? urls[0] : urls[0] + "/";
            map[t] = u.endsWith("domain/") ? u : u + "domain/";
          }
        }
        ianaBootstrapCache = map;
        return map;
      } catch (e) {
        return {};
      }
    })();
  }
  return ianaBootstrapPromise;
}

function fetchWhoisRaw(server, query) {
  return new Promise((resolve) => {
    const client = new net.Socket();
    client.setTimeout(3000);
    let data = "";
    client.connect(43, server, () => {
      client.write(query + "\r\n");
    });
    client.on("data", (chunk) => { data += chunk; });
    client.on("close", () => resolve(data));
    client.on("error", () => resolve(null));
    client.on("timeout", () => {
      client.destroy();
      resolve(null);
    });
  });
}

async function queryWhoisFallback(domain) {
  const parts = domain.split(".");
  const tld = parts[parts.length - 1];
  
  // Step 1: Find the authoritative WHOIS server for the TLD from IANA
  const ianaData = await fetchWhoisRaw("whois.iana.org", tld);
  if (!ianaData) return "UNKNOWN";
  
  const match = ianaData.match(/whois:\s+([a-zA-Z0-9.-]+)/i);
  if (!match || !match[1]) return "UNKNOWN"; // No whois server found for TLD

  const whoisServer = match[1];

  // Step 2: Query the actual WHOIS server
  const whoisData = await fetchWhoisRaw(whoisServer, domain);
  if (!whoisData) return "UNKNOWN";

  const lower = whoisData.toLowerCase();
  
  // Common "not found" patterns across different registries
  if (
    lower.includes("no match") ||
    lower.includes("not found") ||
    lower.includes("no data found") ||
    lower.includes("is free") ||
    lower.includes("available for registration") ||
    lower.includes("do not have an entry")
  ) {
    return "NOT_FOUND_IN_REGISTRY";
  }

  // Common "taken" patterns
  if (
    lower.includes("domain name:") ||
    lower.includes("nserver:") ||
    lower.includes("status:") ||
    lower.includes("registrant:")
  ) {
    return "TAKEN";
  }

  return "UNKNOWN";
}

export async function queryRdap(url, domain) {
  try {
    const res = await fetchWithTimeout(url, {
      headers: { 
        "User-Agent": USER_AGENT,
        "Accept": "application/rdap+json" 
      },
      timeout: 4500
    });

    if (res.status === 200) {
      try {
        const data = await res.json();
        const statuses = data.status || [];
        const events = data.events || [];
        const entities = data.entities || [];
        
        let creationDate, expirationDate;
        events.forEach(ev => {
          if (ev.eventAction === "registration") creationDate = ev.eventDate;
          if (ev.eventAction === "expiration") expirationDate = ev.eventDate;
        });

        let registrant = "Redacted/Private";
        entities.forEach(ent => {
          if (ent.roles && ent.roles.includes("registrant")) {
            if (ent.vcardArray && ent.vcardArray[1]) {
              const fn = ent.vcardArray[1].find(v => v[0] === "fn");
              if (fn) registrant = fn[3];
            }
          }
        });

        return { status: "TAKEN", details: { rdapStatus: statuses, creationDate, expirationDate, registrant, raw: data } };
      } catch (err) {
        return { status: "TAKEN", details: {} };
      }
    } 
    
    if (res.status === 404) {
      return { status: "NOT_FOUND_IN_REGISTRY" };
    } 
    
    if (res.status === 429) {
      const fallback = await queryWhoisFallback(domain);
      return { status: fallback };
    }

    return { status: "UNKNOWN" };
  } catch (e) {
    if (e.name === 'AbortError') {
      return { status: "TIMEOUT" };
    }
    return { status: "UNKNOWN" };
  }
}

export async function checkDomainStatus(domain, tld, returnFullDetails = false) {
  let base = BUILTIN_RDAP_BASES[tld];
  if (!base) {
    const ianaMap = await getIanaMap();
    if (ianaMap && ianaMap[tld]) {
      base = ianaMap[tld];
    }
  }

  if (base) {
    const targetUrl = base.endsWith("/") ? base + domain : base + "/" + domain;
    const result = await queryRdap(targetUrl, domain);
    
    if (returnFullDetails) {
      return result;
    }

    if (result.status === "TAKEN" || result.status === "NOT_FOUND_IN_REGISTRY") {
      return result.status;
    }
  }

  // Authoritative DNS Name Server delegation fallback
  try {
    const ns = await dns.resolveNs(domain);
    if (ns && ns.length > 0) return returnFullDetails ? { status: "TAKEN", details: { dns: ns } } : "TAKEN";
  } catch (err) {
    if (err.code === "ENOTFOUND" || err.code === "ENODATA") {
      return returnFullDetails ? { status: "NOT_FOUND_IN_REGISTRY" } : "NOT_FOUND_IN_REGISTRY";
    }
  }

  return returnFullDetails ? { status: "UNKNOWN" } : "UNKNOWN";
}
